# Brave — Safe Core Build

This build intentionally keeps only the core voice-assistant capabilities:
- microphone voice input
- Hindi/Hinglish / English selection
- alarm and timer
- opening installed apps
- foreground microphone service

Removed from the manifest and app UI:
- Contacts access
- SMS sending
- direct phone calls
- display-over-other-apps permission
- Accessibility Service
- Notification Listener
- WhatsApp auto-send/reply automation

The goal is to reduce sensitive Android capabilities and make sideloading safer and easier. Play Protect can still show a warning for an APK installed outside Google Play; that is controlled by Android/Google and is not something the app should bypass.
