package com.imran.brave

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Safe/core command handler. No contacts, SMS, phone-call, overlay,
 * accessibility or notification-reading APIs are used in this build.
 */
class CommandHandler(private val ctx: Context) {
    var followUp: ((String) -> String)? = null
    var stopNow = false

    private val owner = "Imran"

    fun handle(raw: String): String {
        followUp = null
        stopNow = false
        val t = raw.lowercase(Locale.ROOT).replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty()) return "Kuch suna nahi, dobara bolo."
        return try { route(t) } catch (e: Exception) {
            "Kuch gadbad ho gayi: ${e.message ?: "pata nahi"}"
        }
    }

    private fun route(t: String): String {
        if (has(t, "band ho ja", "band ho jao", "बंद हो जा", "बंद हो जाओ", "stop brave", "ब्रेव बंद")) {
            stopNow = true
            return "Theek hai $owner, band ho raha hoon."
        }
        if (has(t, "timer", "टाइमर") ||
            (has(t, "minute", "मिनट", "ghante", "ghanta", "घंटे", "घंटा") && has(t, "baad", "बाद"))) {
            return setTimer(t)
        }
        if (has(t, "alarm", "अलार्म", "jaga", "जगा", "uthana", "उठा")) return setAlarm(t)
        if (has(t, *openWords)) return openApp(t)
        if (has(t, "time", "टाइम", "samay", "समय", "kitne baje", "कितने बजे", "baj rahe", "बज रहे")) {
            val now = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())
            return "Abhi $now ho rahe hain."
        }
        if (has(t, "date", "तारीख", "tarikh", "aaj kaun", "आज कौन", "kaun sa din", "कौन सा दिन")) {
            val d = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
            return "Aaj $d hai."
        }
        if (has(t, "kaise ho", "कैसे हो", "how are you")) return "Main badhiya hoon $owner, tum batao?"
        if (has(t, "tum kaun", "तुम कौन", "tumhara naam", "तुम्हारा नाम", "who are you")) return "Main Brave hoon, $owner ka personal assistant."
        if (has(t, "shukriya", "शुक्रिया", "thank", "धन्यवाद", "thanks")) return "Koi baat nahi $owner!"
        if (has(t, "hello", "hi ", "हेलो", "namaste", "नमस्ते")) return "Haan $owner, bolo kya karna hai?"
        return "Ye mujhe samajh nahi aaya. Alarm, timer, app kholna ya time pooch kar dekho."
    }

    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }

    private val openWords = arrayOf("open", "kholo", "khol", "खोलो", "खोल", "chalu", "चालू", "launch", "chalao", "चलाओ", "start")

    private val numWords = mapOf(
        "ek" to 1, "एक" to 1, "one" to 1, "do" to 2, "दो" to 2, "two" to 2,
        "teen" to 3, "तीन" to 3, "three" to 3, "char" to 4, "chaar" to 4, "चार" to 4, "four" to 4,
        "paanch" to 5, "panch" to 5, "पांच" to 5, "पाँच" to 5, "five" to 5,
        "chhe" to 6, "chhah" to 6, "che" to 6, "छह" to 6, "छः" to 6, "six" to 6,
        "saat" to 7, "सात" to 7, "seven" to 7, "aath" to 8, "आठ" to 8, "eight" to 8,
        "nau" to 9, "नौ" to 9, "nine" to 9, "das" to 10, "दस" to 10, "ten" to 10,
        "gyarah" to 11, "ग्यारह" to 11, "eleven" to 11, "barah" to 12, "बारह" to 12, "twelve" to 12
    )

    private fun findHourMinute(t: String): Pair<Int, Int>? {
        Regex("(\\d{1,2})\\s*[:.]\\s*(\\d{2})").find(t)?.let {
            return it.groupValues[1].toInt() to it.groupValues[2].toInt()
        }
        Regex("(\\d{1,2})\\s*(?:baje|बजे|bje|bajkar|बजकर)(?:\\s+(\\d{1,2})\\s*(?:minute|min|मिनट)?)?").find(t)?.let {
            return it.groupValues[1].toInt() to (it.groupValues[2].ifEmpty { "0" }.toInt())
        }
        Regex("(\\d{1,2})\\s*(?:am|pm|a\\.m|p\\.m)").find(t)?.let {
            return it.groupValues[1].toInt() to 0
        }
        val toks = t.split(" ")
        for (i in toks.indices) {
            val n = numWords[toks[i]] ?: continue
            if (toks.getOrNull(i + 1) in setOf("baje", "बजे", "bje", "bajkar", "बजकर")) return n to 0
        }
        Regex("\\b(\\d{1,2})\\b").find(t)?.let { return it.groupValues[1].toInt() to 0 }
        return null
    }

    private fun setAlarm(t: String): String {
        val hm = findHourMinute(t) ?: run {
            followUp = { s -> setAlarm(s.lowercase(Locale.ROOT)) }
            return "Kitne baje ka alarm lagaun?"
        }
        var h = hm.first
        val m = hm.second.coerceIn(0, 59)
        if (h > 23) return "Time samajh nahi aaya, dobara bolo."
        val pm = Regex("\\b(pm|p\\.m)\\b").containsMatchIn(t) || has(t, "shaam", "sham", "शाम", "raat", "रात", "dopahar", "दोपहर", "evening", "night", "afternoon")
        val am = Regex("\\b(am|a\\.m)\\b").containsMatchIn(t) || has(t, "subah", "सुबह", "savere", "सवेरे", "morning")
        if (h == 12 && has(t, "raat", "रात")) h = 0
        else if (pm && h in 1..11) h += 12
        else if (am && h == 12) h = 0
        else if (!pm && !am && h in 1..12) {
            val now = Calendar.getInstance()
            val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
            val a = (h % 12) * 60 + m
            val b = a + 720
            h = if (a > nowMin) h % 12 else if (b > nowMin) (h % 12) + 12 else h % 12
        }
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Brave")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        start(i)
        val h12 = if (h % 12 == 0) 12 else h % 12
        return String.format(Locale.ENGLISH, "Alarm %d:%02d %s ke liye laga diya.", h12, m, if (h < 12) "AM" else "PM")
    }

    private fun setTimer(t: String): String {
        var secs = 0
        Regex("(\\d+)\\s*(?:ghante|ghanta|घंटे|घंटा|hour|hr)").find(t)?.let { secs += it.groupValues[1].toInt() * 3600 }
        Regex("(\\d+)\\s*(?:minute|min|मिनट)").find(t)?.let { secs += it.groupValues[1].toInt() * 60 }
        if (secs == 0) {
            val toks = t.split(" ")
            for (i in toks.indices) {
                val n = numWords[toks[i]] ?: continue
                val nxt = toks.getOrNull(i + 1) ?: ""
                if (nxt.startsWith("minute") || nxt.startsWith("मिनट") || nxt == "min") secs += n * 60
                else if (nxt.startsWith("ghant") || nxt.startsWith("घंट") || nxt.startsWith("hour")) secs += n * 3600
            }
        }
        if (secs == 0) {
            followUp = { s -> setTimer(s.lowercase(Locale.ROOT)) }
            return "Kitne minute ka timer lagaun?"
        }
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Brave")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        start(i)
        val h = secs / 3600
        val m = (secs % 3600) / 60
        val label = buildString {
            if (h > 0) append("$h ghante ")
            if (m > 0) append("$m minute ")
            if (h == 0 && m == 0) append("$secs second ")
        }
        return "${label}ka timer laga diya."
    }

    private val aliases = linkedMapOf(
        "youtube" to listOf("youtube", "यूट्यूब", "यूटयूब", "यू ट्यूब"),
        "instagram" to listOf("instagram", "इंस्टाग्राम", "insta"),
        "capcut" to listOf("capcut", "cap cut", "कैपकट", "कैप कट"),
        "inshot" to listOf("inshot", "in shot", "इनशॉट"),
        "kinemaster" to listOf("kinemaster", "किनेमास्टर"),
        "camera" to listOf("camera", "कैमरा"),
        "chrome" to listOf("chrome", "क्रोम"),
        "gallery" to listOf("gallery", "गैलरी"),
        "settings" to listOf("settings", "सेटिंग"),
        "maps" to listOf("maps", "मैप्स", "मैप"),
        "spotify" to listOf("spotify", "स्पॉटिफाई"),
        "telegram" to listOf("telegram", "टेलीग्राम"),
        "facebook" to listOf("facebook", "फेसबुक"),
        "snapchat" to listOf("snapchat", "स्नैपचैट"),
        "calculator" to listOf("calculator", "कैलकुलेटर"),
        "clock" to listOf("clock", "घड़ी", "घडी"),
        "phone" to listOf("phone", "dialer", "फोन"),
        "whatsapp" to listOf("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "वाट्सएप")
    )

    private val openNoise = setOf(
        "open", "kholo", "khol", "खोलो", "खोल", "chalu", "चालू", "launch", "chalao", "चलाओ", "start",
        "app", "ऐप", "ko", "को", "karo", "करो", "do", "दो", "de", "दे", "zara", "jara", "जरा", "please",
        "hello", "brave", "pe", "par", "पे", "पर", "jao", "जाओ", "kar", "कर", "on"
    )

    private fun openApp(t: String): String {
        val name = t.split(" ").filter { it.isNotBlank() && it !in openNoise }.joinToString(" ")
        if (name.isBlank()) {
            followUp = { s -> launchByName(s.lowercase(Locale.ROOT)) }
            return "Kaunsa app kholun?"
        }
        return launchByName(name)
    }

    private fun launchByName(name: String): String {
        val key = aliases.entries.firstOrNull { e -> e.value.any { name.contains(it) } }?.key ?: name
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(main, 0)
        fun label(r: android.content.pm.ResolveInfo) = r.loadLabel(pm).toString().lowercase(Locale.ROOT)
        val hit = list.firstOrNull { label(it) == key } ?: list.firstOrNull { label(it).contains(key) }
            ?: return "'$name' naam ka app mujhe nahi mila."
        val li = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "Is app ko khol nahi paya."
        start(li)
        return "${hit.loadLabel(pm)} khol raha hoon."
    }

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}
