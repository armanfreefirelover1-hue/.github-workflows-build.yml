package com.imran.brave

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Safe/core Brave build: voice assistant + alarm/timer + opening apps.
 * Sensitive capabilities such as contacts, SMS, phone calls, overlay,
 * accessibility and notification-reading are intentionally not requested.
 */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var langBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun label(txt: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = txt
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, pad / 2)
        }

        fun btn(txt: String, onClick: () -> Unit) = Button(this).apply {
            text = txt
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        col.addView(label("BRAVE", 36f, true))
        col.addView(label("Tumhara personal voice assistant. Bolo: \"Hello Brave\"", 15f))
        status = label("", 18f, true)
        col.addView(status)
        col.addView(label("Safe build: microphone + alarm/timer + apps open karna.", 14f))
        col.addView(label("Contacts, SMS, calls, overlay, Accessibility aur notification-reading is build mein disabled hain.", 13f))

        col.addView(btn("🎤 Microphone permission do") { askMicPermission() })
        col.addView(btn("🔋 Battery settings kholo") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        langBtn = btn("") { toggleLanguage() }
        col.addView(langBtn)

        col.addView(btn("▶  BRAVE START") { startBrave() })
        col.addView(btn("■  BRAVE STOP") {
            stopService(Intent(this, BraveService::class.java))
            status.postDelayed({ refresh() }, 400)
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun askMicPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS),
                10
            )
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun startBrave() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Pehle microphone permission do.", Toast.LENGTH_LONG).show()
            askMicPermission()
            return
        }
        val i = Intent(this, BraveService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        status.postDelayed({ refresh() }, 500)
    }

    private fun toggleLanguage() {
        val p = getSharedPreferences("brave", MODE_PRIVATE)
        val next = if (p.getString("lang", "hi-IN") == "hi-IN") "en-IN" else "hi-IN"
        p.edit().putString("lang", next).apply()
        refresh()
    }

    private fun refresh() {
        status.text = if (BraveService.running) "● Brave sun raha hai" else "○ Brave band hai"
        val lang = getSharedPreferences("brave", MODE_PRIVATE).getString("lang", "hi-IN")
        langBtn.text = if (lang == "hi-IN") {
            "Bhasha: Hindi/Hinglish (English ke liye tap)"
        } else {
            "Bhasha: English (Hindi ke liye tap)"
        }
    }
}
