# BRAVE: Imran ka personal assistant (Android)

"Hello Brave" bolo, phone lock ho tab bhi. Brave ye kaam karta hai:

| Bolo | Kya hoga |
|---|---|
| Hello Brave, 7 baje ka alarm lagao | Alarm set |
| Hello Brave, 10 minute ka timer | Timer set |
| Hello Brave, YouTube kholo / CapCut kholo | App open |
| Hello Brave, Rahul ko message bhejo kal milte hain | SMS bhejega |
| Hello Brave, WhatsApp pe Rahul ko message bhejo kal milte hain | WhatsApp pe bhejega |
| Hello Brave, Rahul ko call karo | Call |
| Hello Brave, naya message padho | Aakhri message padhega |
| Hello Brave, reply bhejo theek hai aata hoon | Aakhri message ko reply |
| Hello Brave, time kya hua / aaj kaun sa din | Time, date |
| Hello Brave, band ho ja | Brave band |

Seedha ek saath bol sakte ho ("Hello Brave 7 baje alarm lagao") ya pehle "Hello Brave", jawab ke baad command.

## APK kaise banaye (2 tareeke)

### Tareeka A: Android Studio (computer pe)
1. Android Studio install karo (developer.android.com/studio).
2. File > Open > ye `Brave` folder choose karo. Gradle sync hone do.
3. Phone mein Developer options > USB debugging on karo, phone USB se lagao, Run dabao.
   Ya Build > Build APK(s), phir APK phone mein bhej do.

### Tareeka B: Bina Android Studio, cloud mein (free)
1. GitHub pe free account banao, naya repository banao.
2. Is poore folder ke files (`.github` folder samet) us repository mein upload karo.
3. Actions tab > "Build Brave APK" > Run workflow.
4. 5 se 10 minute baad Brave-APK artifact download karo, zip kholke app-debug.apk phone pe install karo.

## Pehli baar setup (app ke andar 1 se 5)
1. Permissions do (mic, contacts, SMS, call)
2. Display over other apps on karo (taaki Brave background se app khol sake)
3. Notification access (taaki messages padh aur reply kar sake)
4. Accessibility (WhatsApp ka Send button apne aap dabane ke liye)
5. Battery "Unrestricted" (Xiaomi/Oppo/Vivo/Realme mein "Autostart" bhi on karo)

Phir "BRAVE START" dabao. Upar notification dikhega, matlab Brave sun raha hai.

## Tips
- Google app mein offline speech pack download kar lo (Google app > Settings > Voice > Offline speech recognition > Hindi aur English). Tab net ke bina bhi chalega aur tez bhi.
- Contact ka naam Devanagari mein aaye aur contact English mein saved ho to match nahi hoga. Tab app mein bhasha English kar do ya naam English mein bolo.
- Brave on rehta hai tab notification ki awaaz band rehti hai (beep hatane ke liye). Brave STOP karoge to wapas aa jayegi.
- Hamesha sunne se battery thodi zyada jati hai.

## Limits (sach)
- Ye rule-based hai, koi AI API nahi. Wo hi cheezein samajhta hai jo upar likhi hain. Baad mein chaho to Claude API laga kar isko sach mein "samajhdar" bana sakte hain.
- Sirf Android. iPhone pe Apple ye allow nahi karta.
