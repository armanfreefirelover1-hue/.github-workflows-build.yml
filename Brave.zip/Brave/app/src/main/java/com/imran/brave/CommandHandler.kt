package com.imran.brave

import android.Manifest
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.telephony.SmsManager
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Brave ka "dimag". Ye rule-based hai (koi API nahi, bilkul free):
 * tumhari bolti hui line ko padhkar decide karta hai ki kaunsa kaam karna hai.
 */
class CommandHandler(private val ctx: Context) {

    /** Agar Brave ko jawab ke liye aur sunna hai (jaise "kya message bhejun?") to function yahan rehta hai. */
    var followUp: ((String) -> String)? = null

    /** True ho to service band ho jayegi. */
    var stopNow = false

    private val owner = "Imran"

    fun handle(raw: String): String {
        followUp = null
        stopNow = false
        val t = raw.lowercase(Locale.ROOT).replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty()) return "Kuch suna nahi, dobara bolo."
        return try {
            route(t)
        } catch (e: Exception) {
            "Kuch gadbad ho gayi: ${e.message ?: "pata nahi"}"
        }
    }

    // ---------------------------------------------------------------- routing

    private fun route(t: String): String {
        if (has(t, "band ho ja", "band ho jao", "बंद हो जा", "बंद हो जाओ", "stop brave", "ब्रेव बंद")) {
            stopNow = true
            return "Theek hai $owner, band ho raha hoon."
        }
        if (has(t, "timer", "टाइमर") ||
            (has(t, "minute", "मिनट", "ghante", "ghanta", "घंटे", "घंटा") && has(t, "baad", "बाद"))
        ) return setTimer(t)
        if (has(t, "alarm", "अलार्म", "jaga", "जगा", "uthana", "उठा")) return setAlarm(t)
        if (has(t, "reply", "रिप्लाई", "jawab", "जवाब")) return replyLast(t)
        if (has(t, "padho", "पढ़ो", "sunao", "सुनाओ", "kiska message", "किसका मैसेज", "naya message", "नया मैसेज", "new message")) return readLast()

        val msg = if (has(t, *msgWords)) parseMessage(t) else null
        if (msg != null) return sendMessage(msg.first, msg.second, has(t, *waWords))

        if (has(t, *openWords)) return openApp(t)
        if (has(t, "call", "कॉल", "phone lagao", "फोन लगा", "फ़ोन लगा", "dial", "milao", "मिलाओ")) return callContact(t)

        if (has(t, "time", "टाइम", "samay", "समय", "kitne baje", "कितने बजे", "baj rahe", "बज रहे")) {
            val now = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())
            return "Abhi $now ho rahe hain."
        }
        if (has(t, "date", "तारीख", "tarikh", "aaj kaun", "आज कौन", "kaun sa din", "कौन सा दिन")) {
            val d = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
            return "Aaj $d hai."
        }
        if (has(t, "kaise ho", "कैसे हो", "how are you")) return "Main badhiya hoon $owner, tum batao?"
        if (has(t, "tum kaun", "तुम कौन", "tumhara naam", "तुम्हारा नाम", "who are you")) return "Main Brave hoon, $owner ka personal assistant."
        if (has(t, "shukriya", "शुक्रिया", "thank", "धन्यवाद", "thanks")) return "Koi baat nahi $owner!"
        if (has(t, "hello", "hi ", "हेलो", "namaste", "नमस्ते")) return "Haan $owner, bolo kya karna hai?"

        return "Ye mujhe samajh nahi aaya. Alarm, app kholna, message ya call bol ke dekho."
    }

    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }

    private fun granted(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    // ------------------------------------------------------------ word lists

    private val msgWords = arrayOf("message", "msg", "sms", "मैसेज", "मेसेज", "संदेश", "sandesh")
    private val msgSet = msgWords.toSet()
    private val waWords = arrayOf("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "वाट्सएप", "whats app")
    private val openWords = arrayOf("open", "kholo", "khol", "खोलो", "खोल", "chalu", "चालू", "launch", "chalao", "चलाओ", "start")

    private val markers = setOf(
        "bhejo", "bhej", "do", "de", "दो", "दे", "भेजो", "भेज", "भेजना", "karo", "kar", "करो", "कर",
        "ki", "कि", "ke", "likho", "likh", "लिखो", "लिख", "bolo", "बोलो", "saying", "that", "dena", "देना"
    )
    private val nameNoise = setOf(
        "send", "message", "msg", "sms", "whatsapp", "pe", "par", "पे", "पर", "मैसेज", "मेसेज",
        "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "वाट्सएप", "एक", "ek", "hello", "brave", "हेलो", "ब्रेव",
        "please", "ko", "को", "to", "a", "the", "abhi", "अभी", "jara", "zara", "जरा"
    )
    private val bodyDrop = markers + msgSet + setOf(
        "ko", "को", "pe", "par", "पे", "पर", "whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "वाट्सएप",
        "please", "jara", "zara", "जरा"
    )

    // ------------------------------------------------------------------ alarm

    private val numWords = mapOf(
        "ek" to 1, "एक" to 1, "one" to 1, "do" to 2, "दो" to 2, "two" to 2,
        "teen" to 3, "तीन" to 3, "three" to 3, "char" to 4, "chaar" to 4, "चार" to 4, "four" to 4,
        "paanch" to 5, "panch" to 5, "पांच" to 5, "पाँच" to 5, "five" to 5,
        "chhe" to 6, "chhah" to 6, "che" to 6, "छह" to 6, "छः" to 6, "six" to 6,
        "saat" to 7, "सात" to 7, "seven" to 7, "aath" to 8, "आठ" to 8, "eight" to 8,
        "nau" to 9, "नौ" to 9, "nine" to 9, "das" to 10, "दस" to 10, "ten" to 10,
        "gyarah" to 11, "ग्यारह" to 11, "eleven" to 11, "barah" to 12, "बारह" to 12, "twelve" to 12
    )
    private val bajeSet = setOf("baje", "बजे", "bje", "bajkar", "बजकर", "bajke")

    private fun findHourMinute(t: String): Pair<Int, Int>? {
        Regex("(\\d{1,2})\\s*[:.]\\s*(\\d{2})").find(t)?.let {
            return it.groupValues[1].toInt() to it.groupValues[2].toInt()
        }
        Regex("(\\d{1,2})\\s*(?:baje|बजे|bje|bajkar|बजकर)(?:\\s+(\\d{1,2})\\s*(?:minute|min|मिनट)?)?").find(t)?.let {
            val m = it.groupValues[2].ifEmpty { "0" }.toInt()
            return it.groupValues[1].toInt() to m
        }
        Regex("(\\d{1,2})\\s*(?:am|pm|a\\.m|p\\.m)").find(t)?.let {
            return it.groupValues[1].toInt() to 0
        }
        val toks = t.split(" ")
        for (i in toks.indices) {
            val n = numWords[toks[i]] ?: continue
            if ((toks.getOrNull(i + 1) ?: "") in bajeSet) return n to 0
        }
        Regex("\\b(\\d{1,2})\\b").find(t)?.let { return it.groupValues[1].toInt() to 0 }
        return null
    }

    private fun setAlarm(t: String): String {
        val hm = findHourMinute(t)
        if (hm == null) {
            followUp = { s -> setAlarm(s.lowercase(Locale.ROOT)) }
            return "Kitne baje ka alarm lagaun?"
        }
        var h = hm.first
        var m = hm.second.coerceIn(0, 59)
        if (h > 23) return "Time samajh nahi aaya, dobara bolo."
        if (has(t, "sade", "साढ़े", "साढे") && m == 0) m = 30

        val pm = Regex("\\b(pm|p\\.m)\\b").containsMatchIn(t) ||
            has(t, "shaam", "sham", "शाम", "raat", "रात", "dopahar", "दोपहर", "evening", "night", "afternoon")
        val am = Regex("\\b(am|a\\.m)\\b").containsMatchIn(t) ||
            has(t, "subah", "सुबह", "savere", "सवेरे", "morning")

        if (h == 12 && has(t, "raat", "रात")) {
            h = 0
        } else if (pm && h in 1..11) {
            h += 12
        } else if (am && h == 12) {
            h = 0
        } else if (!pm && !am && h in 1..12) {
            val now = Calendar.getInstance()
            val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
            val a = (h % 12) * 60 + m
            val b = a + 12 * 60
            h = if (a > nowMin) h % 12 else if (b > nowMin) (h % 12) + 12 else h % 12
        }

        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Brave")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        start(i)
        val h12 = if (h % 12 == 0) 12 else h % 12
        return String.format(Locale.ENGLISH, "Alarm %d:%02d %s ke liye laga diya.", h12, m, if (h < 12) "AM" else "PM")
    }

    private fun setTimer(t: String): String {
        var secs = 0
        Regex("(\\d+)\\s*(?:ghante|ghanta|घंटे|घंटा|hour|hr)").find(t)?.let { secs += it.groupValues[1].toInt() * 3600 }
        Regex("(\\d+)\\s*(?:minute|min|मिनट)").find(t)?.let { secs += it.groupValues[1].toInt() * 60 }
        if (secs == 0) {
            val toks = t.split(" ")
            for (i in toks.indices) {
                val n = numWords[toks[i]] ?: continue
                val nxt = toks.getOrNull(i + 1) ?: ""
                if (nxt.startsWith("minute") || nxt.startsWith("मिनट") || nxt == "min") secs += n * 60
                else if (nxt.startsWith("ghant") || nxt.startsWith("घंट") || nxt.startsWith("hour")) secs += n * 3600
            }
        }
        if (secs == 0) {
            followUp = { s -> setTimer(s.lowercase(Locale.ROOT)) }
            return "Kitne minute ka timer lagaun?"
        }
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Brave")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        start(i)
        val h = secs / 3600
        val m = (secs % 3600) / 60
        val label = buildString {
            if (h > 0) append("$h ghante ")
            if (m > 0) append("$m minute ")
            if (h == 0 && m == 0) append("$secs second ")
        }
        return "${label}ka timer laga diya."
    }

    // -------------------------------------------------------------- open app

    private val aliases = linkedMapOf(
        "youtube" to listOf("youtube", "यूट्यूब", "यूटयूब", "यू ट्यूब"),
        "whatsapp" to listOf("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "वाट्सएप"),
        "instagram" to listOf("instagram", "इंस्टाग्राम", "insta"),
        "capcut" to listOf("capcut", "cap cut", "कैपकट", "कैप कट"),
        "inshot" to listOf("inshot", "in shot", "इनशॉट"),
        "kinemaster" to listOf("kinemaster", "किनेमास्टर"),
        "camera" to listOf("camera", "कैमरा"),
        "chrome" to listOf("chrome", "क्रोम"),
        "gallery" to listOf("gallery", "गैलरी"),
        "settings" to listOf("settings", "सेटिंग"),
        "maps" to listOf("maps", "मैप्स", "मैप"),
        "phonepe" to listOf("phonepe", "phone pe", "फोनपे", "फोन पे"),
        "google pay" to listOf("google pay", "gpay", "g pay", "गूगल पे", "जीपे"),
        "spotify" to listOf("spotify", "स्पॉटिफाई"),
        "telegram" to listOf("telegram", "टेलीग्राम"),
        "facebook" to listOf("facebook", "फेसबुक"),
        "snapchat" to listOf("snapchat", "स्नैपचैट"),
        "calculator" to listOf("calculator", "कैलकुलेटर"),
        "clock" to listOf("clock", "घड़ी", "घडी"),
        "contacts" to listOf("contacts", "कॉन्टैक्ट"),
        "phone" to listOf("phone", "dialer", "फोन")
    )
    private val openNoise = setOf(
        "open", "kholo", "khol", "खोलो", "खोल", "chalu", "चालू", "launch", "chalao", "चलाओ", "start",
        "app", "ऐप", "ko", "को", "karo", "करो", "do", "दो", "de", "दे", "zara", "jara", "जरा", "please",
        "hello", "brave", "pe", "par", "पे", "पर", "jao", "जाओ", "kar", "कर", "on"
    )

    private fun openApp(t: String): String {
        val name = t.split(" ").filter { it.isNotBlank() && it !in openNoise }.joinToString(" ")
        if (name.isBlank()) {
            followUp = { s -> launchByName(s.lowercase(Locale.ROOT)) }
            return "Kaunsa app kholun?"
        }
        return launchByName(name)
    }

    private fun launchByName(name: String): String {
        val key = aliases.entries.firstOrNull { e -> e.value.any { name.contains(it) } }?.key ?: name
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(main, 0)
        fun label(r: android.content.pm.ResolveInfo) = r.loadLabel(pm).toString().lowercase(Locale.ROOT)
        val hit = list.firstOrNull { label(it) == key } ?: list.firstOrNull { label(it).contains(key) }
            ?: return "'$name' naam ka app mujhe nahi mila."
        val li = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "Is app ko khol nahi paya."
        start(li)
        return "${hit.loadLabel(pm)} khol raha hoon."
    }

    // -------------------------------------------------------------- contacts

    private fun findContact(name: String): Pair<String, String>? {
        if (!granted(Manifest.permission.READ_CONTACTS)) return null
        val cur = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"),
            null
        ) ?: return null
        cur.use {
            if (it.moveToFirst()) return it.getString(0) to it.getString(1)
        }
        return null
    }

    // --------------------------------------------------------------- message

    private fun parseMessage(t: String): Pair<String, String>? {
        val toks = t.split(" ").filter { it.isNotBlank() }
        var idx = toks.indexOfFirst { it == "ko" || it == "को" }
        if (idx < 0) idx = toks.indexOfFirst { it == "to" }
        if (idx < 0) return null

        var nameToks = toks.subList(0, idx).filter { it !in nameNoise && it !in msgSet }
        var rest = toks.subList(idx + 1, toks.size)
        if (toks[idx] == "to") {
            if (rest.isEmpty()) return null
            nameToks = listOf(rest[0])
            rest = rest.drop(1)
        }
        val name = nameToks.joinToString(" ")
        if (name.isBlank()) return null
        val body = rest.dropWhile { it in bodyDrop }.joinToString(" ")
        return name to body
    }

    private fun sendMessage(name: String, body: String, whatsapp: Boolean): String {
        if (!granted(Manifest.permission.READ_CONTACTS)) return "Pehle Brave app mein Contacts ki permission do."
        val c = findContact(name) ?: return "Contacts mein '$name' nahi mila. Naam English mein bolke dekho."
        if (body.isBlank()) {
            followUp = { b -> sendMessage(name, b, whatsapp) }
            return "${c.first} ko kya message bhejun?"
        }
        return if (whatsapp) sendWhatsApp(c, body) else sendSms(c, body)
    }

    private fun sendSms(c: Pair<String, String>, body: String): String {
        if (!granted(Manifest.permission.SEND_SMS)) return "Pehle Brave app mein SMS ki permission do."
        val sms: SmsManager = if (Build.VERSION.SDK_INT >= 31) {
            ctx.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION") SmsManager.getDefault()
        }
        val parts = sms.divideMessage(body)
        sms.sendMultipartTextMessage(c.second, null, parts, null, null)
        return "${c.first} ko SMS bhej diya."
    }

    private fun isInstalled(pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun sendWhatsApp(c: Pair<String, String>, body: String): String {
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { isInstalled(it) }
            ?: return "Phone mein WhatsApp installed nahi hai."
        var num = c.second.filter { it.isDigit() }
        if (num.length == 10) num = "91$num"
        val enc = URLEncoder.encode(body, "UTF-8").replace("+", "%20")
        BraveState.autoSendUntil = System.currentTimeMillis() + 20000
        start(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num?text=$enc")).setPackage(pkg))
        return "${c.first} ko WhatsApp pe message bhej raha hoon."
    }

    // ------------------------------------------------------------------ call

    private val callNoise = setOf(
        "call", "कॉल", "phone", "फोन", "फ़ोन", "lagao", "लगाओ", "laga", "लगा", "do", "दो", "karo", "करो",
        "milao", "मिलाओ", "dial", "ko", "को", "pe", "par", "please", "hello", "brave", "हेलो", "ब्रेव", "kar", "कर"
    )

    private fun callContact(t: String): String {
        val name = t.split(" ").filter { it.isNotBlank() && it !in callNoise }.joinToString(" ")
        if (name.isBlank()) {
            followUp = { s -> callByName(s.lowercase(Locale.ROOT)) }
            return "Kisko call karun?"
        }
        return callByName(name)
    }

    private fun callByName(name: String): String {
        if (!granted(Manifest.permission.READ_CONTACTS)) return "Pehle Brave app mein Contacts ki permission do."
        val c = findContact(name) ?: return "Contacts mein '$name' nahi mila."
        val uri = Uri.parse("tel:" + Uri.encode(c.second))
        if (granted(Manifest.permission.CALL_PHONE)) start(Intent(Intent.ACTION_CALL, uri))
        else start(Intent(Intent.ACTION_DIAL, uri))
        return "${c.first} ko call laga raha hoon."
    }

    // ------------------------------------------------- read / reply messages

    private val replyWords = setOf("reply", "रिप्लाई", "jawab", "जवाब")
    private val replyDrop = markers + setOf(
        "usko", "unko", "isko", "उसको", "उनको", "इसको", "reply", "रिप्लाई", "jawab", "जवाब",
        "message", "ko", "को", "bhejo"
    )

    private fun readLast(): String {
        if (LastMessage.sender.isBlank()) return "Abhi koi naya message nahi hai."
        return "${LastMessage.sender} ka message hai: ${LastMessage.text}"
    }

    private fun replyLast(t: String): String {
        if (LastMessage.action == null) {
            return "Abhi koi aisa message nahi aaya jiska reply de sakun. Notification access on hai?"
        }
        val toks = t.split(" ").filter { it.isNotBlank() }
        val idx = toks.indexOfFirst { it in replyWords }
        val body = toks.drop(idx + 1).dropWhile { it in replyDrop }.joinToString(" ")
        if (body.isBlank()) {
            followUp = { b -> doReply(b) }
            return "${LastMessage.sender} ko kya reply bhejun?"
        }
        return doReply(body)
    }

    private fun doReply(body: String): String {
        val a = LastMessage.action ?: return "Reply karne ke liye koi message nahi mila."
        val ri = a.remoteInputs ?: return "Is message ka reply yahan se nahi ho sakta."
        val intent = Intent()
        val bundle = Bundle()
        for (r in ri) bundle.putCharSequence(r.resultKey, body)
        RemoteInput.addResultsToIntent(ri, intent, bundle)
        a.actionIntent.send(ctx, 0, intent)
        return "${LastMessage.sender} ko reply bhej diya."
    }
}
