package com.imran.brave

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale

/**
 * Background mein chalta hai. Hamesha sunta rehta hai; "Hello Brave" sunte hi jaag jata hai,
 * command sunta hai, CommandHandler se kaam karwata hai aur bolke jawab deta hai.
 */
class BraveService : Service(), RecognitionListener, TextToSpeech.OnInitListener {

    companion object {
        @Volatile var running = false
        private val WAKE = Regex("(brave|brav|ब्रेव|ब्रैव|ब्रेब|breve|bhrave|braves)")
    }

    private enum class Mode { WAKE, COMMAND, BUSY }

    private var mode = Mode.WAKE
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var afterSpeech: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())
    private lateinit var commands: CommandHandler
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        commands = CommandHandler(this)

        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "brave:listen")
            .apply { acquire() }

        muteBeeps(true)
        tts = TextToSpeech(this, this)

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Phone mein speech recognition (Google app) nahi mila.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        createRecognizer()
        mode = Mode.WAKE
        main.postDelayed({ startListening() }, 1200)
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (e: Exception) { }
        tts?.shutdown()
        muteBeeps(false)
        try { wakeLock?.release() } catch (e: Exception) { }
        super.onDestroy()
    }

    // ------------------------------------------------------------ foreground

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("brave", "Brave", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "brave")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Brave chalu hai")
            .setContentText("\"Hello Brave\" bolo")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun muteBeeps(on: Boolean) {
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val flag = if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
            for (s in intArrayOf(AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
                am.adjustStreamVolume(s, flag, 0)
            }
        } catch (e: Exception) { }
    }

    // ------------------------------------------------------- speech: listen

    private fun createRecognizer() {
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
    }

    private fun recreateRecognizer() {
        try { recognizer?.destroy() } catch (e: Exception) { }
        createRecognizer()
    }

    private fun startListening() {
        if (!running) return
        val r = recognizer ?: return
        val lang = getSharedPreferences("brave", MODE_PRIVATE).getString("lang", "hi-IN") ?: "hi-IN"
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            r.startListening(i)
        } catch (e: Exception) {
            recreateRecognizer()
            restart(1000)
        }
    }

    private fun restart(delayMs: Long) {
        main.postDelayed({ if (running && mode == Mode.WAKE) startListening() }, delayMs)
    }

    private fun afterWake(text: String): String? {
        val l = text.lowercase(Locale.ROOT)
        val m = WAKE.find(l) ?: return null
        return l.substring(m.range.last + 1).trim()
    }

    // ------------------------------------------------------ speech: talk back

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val r = tts?.setLanguage(Locale("en", "IN"))
        ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { finishSpeech() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { finishSpeech() }
        })
    }

    private fun finishSpeech() {
        main.post {
            val f = afterSpeech
            afterSpeech = null
            f?.invoke()
        }
    }

    private fun speak(text: String, then: () -> Unit) {
        try { recognizer?.cancel() } catch (e: Exception) { }
        afterSpeech = then
        if (!ttsReady) {
            finishSpeech()
            return
        }
        val res = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "brave")
        if (res != TextToSpeech.SUCCESS) finishSpeech()
    }

    // ------------------------------------------------------------- the flow

    private fun onWake(rest: String) {
        mode = Mode.BUSY
        if (rest.trim().length >= 3) {
            runCommand(rest)
        } else {
            speak("Haan Imran, boliye") {
                mode = Mode.COMMAND
                startListening()
            }
        }
    }

    private fun runCommand(text: String) {
        mode = Mode.BUSY
        val pending = commands.followUp
        val reply = if (pending != null) {
            commands.followUp = null
            pending(text)
        } else {
            commands.handle(text)
        }
        speak(reply) {
            when {
                commands.stopNow -> stopSelf()
                commands.followUp != null -> {
                    mode = Mode.COMMAND
                    startListening()
                }
                else -> {
                    mode = Mode.WAKE
                    startListening()
                }
            }
        }
    }

    override fun onResults(results: Bundle?) {
        val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
        when (mode) {
            Mode.WAKE -> {
                val hit = list.firstNotNullOfOrNull { afterWake(it) }
                if (hit != null) onWake(hit) else restart(150)
            }
            Mode.COMMAND -> runCommand(list.firstOrNull() ?: "")
            Mode.BUSY -> {}
        }
    }

    override fun onError(error: Int) {
        when (mode) {
            Mode.WAKE -> when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    Toast.makeText(this, "Brave ko mic ki permission do.", Toast.LENGTH_LONG).show()
                    stopSelf()
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                SpeechRecognizer.ERROR_CLIENT,
                SpeechRecognizer.ERROR_SERVER,
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                    recreateRecognizer()
                    restart(1000)
                }
                else -> restart(200)
            }
            Mode.COMMAND -> {
                commands.followUp = null
                speak("Kuch suna nahi. Dobara Hello Brave bolo.") {
                    mode = Mode.WAKE
                    startListening()
                }
            }
            Mode.BUSY -> {}
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
