package com.imran.brave

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** WhatsApp mein message pehle se likha khulta hai; ye service uska Send button dabati hai. */
class BraveAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (System.currentTimeMillis() > BraveState.autoSendUntil) return
        val root = rootInActiveWindow ?: return

        var target: AccessibilityNodeInfo? = null
        for (id in listOf("com.whatsapp:id/send", "com.whatsapp.w4b:id/send")) {
            target = root.findAccessibilityNodeInfosByViewId(id).firstOrNull()
            if (target != null) break
        }
        if (target == null) {
            for (label in listOf("Send", "भेजें")) {
                target = root.findAccessibilityNodeInfosByText(label).firstOrNull()
                if (target != null) break
            }
        }
        if (target == null) return

        var node: AccessibilityNodeInfo? = target
        while (node != null && !node.isClickable) node = node.parent
        if (node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            BraveState.autoSendUntil = 0L
        }
    }

    override fun onInterrupt() {}
}
