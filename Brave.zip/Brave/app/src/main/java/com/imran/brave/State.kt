package com.imran.brave

import android.app.Notification

/** Accessibility service ko batata hai ki abhi WhatsApp ka Send dabana hai. */
object BraveState {
    @Volatile var autoSendUntil = 0L
}

/** Sabse naya message jisko reply diya ja sakta hai (notification se). */
object LastMessage {
    @Volatile var sender: String = ""
    @Volatile var text: String = ""
    @Volatile var action: Notification.Action? = null
}
