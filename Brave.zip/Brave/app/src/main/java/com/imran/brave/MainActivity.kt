package com.imran.brave

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var checklist: TextView
    private lateinit var langBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun label(txt: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = txt
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, pad / 2)
        }

        fun btn(txt: String, onClick: () -> Unit) = Button(this).apply {
            text = txt
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        col.addView(label("BRAVE", 36f, true))
        col.addView(label("Tumhara personal assistant. Bolo: \"Hello Brave\"", 15f))
        status = label("", 18f, true)
        col.addView(status)
        checklist = label("", 14f)
        col.addView(checklist)

        col.addView(label("Pehli baar ke liye ye 1 se 5 tak karo:", 14f, true))
        col.addView(btn("1. Permissions do (mic, contacts, SMS, call)") { askPermissions() })
        col.addView(btn("2. 'Display over other apps' on karo") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("3. Notification access do (reply ke liye)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(btn("4. Accessibility on karo (WhatsApp Send ke liye)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("5. Battery 'Unrestricted' karo") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        langBtn = btn("") { toggleLanguage() }
        col.addView(langBtn)

        col.addView(btn("▶  BRAVE START") { startBrave() })
        col.addView(btn("■  BRAVE STOP") {
            stopService(Intent(this, BraveService::class.java))
            status.postDelayed({ refresh() }, 600)
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun askPermissions() {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun startBrave() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Pehle step 1 mein permissions do.", Toast.LENGTH_LONG).show()
            askPermissions()
            return
        }
        val i = Intent(this, BraveService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        status.postDelayed({ refresh() }, 800)
    }

    private fun toggleLanguage() {
        val p = getSharedPreferences("brave", MODE_PRIVATE)
        val next = if (p.getString("lang", "hi-IN") == "hi-IN") "en-IN" else "hi-IN"
        p.edit().putString("lang", next).apply()
        refresh()
    }

    private fun enabledIn(setting: String): Boolean =
        Settings.Secure.getString(contentResolver, setting)?.contains(packageName) == true

    private fun refresh() {
        status.text = if (BraveService.running) "● Brave sun raha hai" else "○ Brave band hai"
        fun ok(b: Boolean) = if (b) "✓" else "✗"
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val contacts = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        checklist.text = listOf(
            "${ok(mic)} Mic",
            "${ok(contacts)} Contacts",
            "${ok(Settings.canDrawOverlays(this))} Display over other apps",
            "${ok(enabledIn("enabled_notification_listeners"))} Notification access",
            "${ok(enabledIn("enabled_accessibility_services"))} Accessibility"
        ).joinToString("\n")
        val lang = getSharedPreferences("brave", MODE_PRIVATE).getString("lang", "hi-IN")
        langBtn.text = if (lang == "hi-IN") "Bhasha: Hindi/Hinglish (English karne ke liye tap)" else "Bhasha: English (Hindi karne ke liye tap)"
    }
}
