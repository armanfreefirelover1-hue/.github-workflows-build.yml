package com.imran.brave

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Incoming messages (WhatsApp, SMS, Telegram...) ko dekhta hai taaki Brave padh sake aur reply bhej sake. */
class BraveNotificationListener : NotificationListenerService() {

    private val chatPackages = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "org.telegram.messenger",
        "com.google.android.apps.messaging",
        "com.samsung.android.messaging",
        "com.instagram.android",
        "com.facebook.orca"
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (n.category != Notification.CATEGORY_MESSAGE && sbn.packageName !in chatPackages) return

        val replyAction = n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true } ?: return
        val extras = n.extras
        LastMessage.sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        LastMessage.text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        LastMessage.action = replyAction
    }
}
